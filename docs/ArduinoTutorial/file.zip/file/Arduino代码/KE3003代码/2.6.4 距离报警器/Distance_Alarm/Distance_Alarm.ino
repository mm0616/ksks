// 引入SoftwareSerial库，用于创建软串口通信
#include <SoftwareSerial.h>

// 创建软串口对象，使用A5作为RX引脚接收数据，A4作为TX引脚发送数据
SoftwareSerial mySerial(A5, A4);

// 定义变量用于存储从语音模块接收到的控制码
volatile int Voice_Control = 0;  // 初始化为0，确保首次判断时不触发任何指令

// 定义传感器连接的引脚号
int EchoPin = 13;  //Echo引脚接D13
int TrigPin = 12;  //Trig引脚接D12

/*
 函数功能：通过串口发送具有固定帧格式的数据包
 数据包格式：帧头(0xAA 0x55) + 消息号数据 + 数据1 + 数据2 + 帧尾(0x55 0xAA)
 
 输入参数说明：
  ---Message_Number ：消息号，用于标识命令类型   <必需填写>
  ---data1 ：第一个数据参数  <如果没有数据就输入0>
  ---data2 ：第二个数据参数  <如果没有数据就输入0>
 */
void Uart_SendCmd(int Message_Number, int data1, int data2) {
  // 发送帧头：固定字节0xAA和0x55，用于标识数据包的开始
  mySerial.write(0XAA);
  mySerial.write(0X55);

  // 发送消息号，标识具体的命令类型
  mySerial.write(Message_Number);

  // 发送两个数据参数
  mySerial.write(data1);
  mySerial.write(data2);

  // 发送帧尾：固定字节0x55和0xAA，用于标识数据包的结束
  mySerial.write(0X55);
  mySerial.write(0XAA);
}

float checkdistance() {
  // 第一步：确保Trig引脚处于低电平状态，为发送高电平脉冲做准备
  digitalWrite(TrigPin, LOW);
  delayMicroseconds(2);  // 维持2微秒低电平，确保信号稳定

  // 第二步：发送10微秒的高电平脉冲，触发超声波发射
  digitalWrite(TrigPin, HIGH);
  delayMicroseconds(10);       // 维持10微秒高电平（符合HC-SR04模块要求）
  digitalWrite(TrigPin, LOW);  // 结束触发信号

  // 距离 = 时间(微秒) ÷ 58
  float distance = pulseIn(EchoPin, HIGH) / 58.00;

  delay(10);        // 等待10毫秒，避免连续测量干扰
  return distance;  // 返回测量结果（单位：厘米）
}

void setup() {
  // 初始化硬件串口，用于调试和监控，波特率9600
  Serial.begin(9600);
  // 初始化软串口，用于与语音模块通信，波特率9600
  mySerial.begin(9600);

  // 将引脚设置为输入模式，用于检测外部信号
  pinMode(TrigPin, OUTPUT);  //Trig引脚为输出
  pinMode(EchoPin, INPUT);   //Echo引脚为输入
}

void loop() {
  //读取传感器的状态并赋值给变量
  int distance = checkdistance();
  //限制测距范围为2-250CM，如果超出就设置距离值为0
  if (distance < 2 || distance >= 250) {
    distance = 0;
    delay(100);
  }

  // 持续检查软串口是否有来自语音模块的数据
  while (mySerial.available()) {
    // 读取一个字节的数据
    Voice_Control = mySerial.read();

    // 将接收到的数据通过硬件串口输出，便于调试和监控
    Serial.println(Voice_Control);
  }

  //通过变量判断传感器是否出发，如果出发则发出警报提示
  if (distance <= 20) {
    // 消息号为12，两个数据参数都为0
    Uart_SendCmd(12, distance, 0);
    delay(10 * 1000);
  }
}